"""
convert_tsrd.py
================

Converts a Turing Synthetic Radar Dataset (TSRD) scan-mode .h5 file into a
scheduler-friendly static RF environment for PS26055 (Smart Scan Strategy
for Electronic Warfare), and runs three baseline scan-scheduling algorithms
(Round Robin, Random, Markov) against it.

IMPORTANT — read before trusting any number this script produces:
TSRD was built for radar pulse deinterleaving, not for PS26055. Everything
this script derives from TSRD is explicitly labeled as one of:
    OBSERVED    -> literally present in the .h5 file
    DERIVED     -> a deterministic transform of observed data (e.g. binning)
    ASSUMPTION  -> a simulation/design choice we made and could change
    GROUND TRUTH -> emitter labels, used ONLY for evaluation, never given
                     to the scheduler at decision time.

Run:
    python convert_tsrd.py --input config_0.h5 --output data/
"""

import argparse
import json
import random
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

# =====================================================================
# CONFIGURABLE PARAMETERS  (all design/simulation assumptions live here)
# =====================================================================

# ASSUMPTION, but justified by ground truth in the .h5 file itself:
# metadata/receiver/bandwith_mhz = 500.0, and metadata/receiver/dwell_centres_mhz
# are 36 centres spaced exactly 500 MHz apart, running 250, 750, ..., 17750 MHz.
# That means the receiver's REAL scanned range is 0-18000 MHz (36 * 500 MHz).
# NOTE: metadata/receiver/freq_range_mhz in this file states [500, 18000],
# which is INCONSISTENT with dwell_centres_mhz (it omits the lowest band,
# centred at 250 MHz, covering 0-500 MHz). We follow dwell_centres_mhz
# because it is the more granular, internally-consistent ground truth, and
# because trusting freq_range_mhz instead would silently discard 9,299 real
# pulses (5.5% of the dataset) that fall in the 0-500 MHz band.
BAND_WIDTH_MHZ = 500.0
FREQ_RANGE_MIN_MHZ = 0.0
FREQ_RANGE_MAX_MHZ = 18000.0

# ASSUMPTION, chosen to match the fine end of TSRD's own dwell_times_s
# (which alternate between 0.05s and 0.1s per band in the source receiver
# config). 50 ms give 600 time slots over the 30s collection window.
TIME_SLOT_MS = 50.0

RANDOM_SEED = 42

# Reward assumption for the "total_reward" metric only (Step 11).
# This is NOT ground truth and NOT used by any scheduler's decision logic.
REWARD_HIT = 1.0
REWARD_MISS = 0.0


def log(msg):
    print(f"[convert_tsrd] {msg}")


# =====================================================================
# STEP 1 — INSPECT (kept here so the script is self-documenting / re-runnable)
# =====================================================================

def inspect_h5(path):
    info = {}
    with h5py.File(path, "r") as f:
        info["num_pulses"] = f["data"].shape[0]
        info["data_shape"] = f["data"].shape
        info["data_dtype"] = str(f["data"].dtype)
        info["labels_shape"] = f["labels"].shape
        info["labels_dtype"] = str(f["labels"].dtype)
        info["feature_names"] = [
            x.decode() if isinstance(x, bytes) else x
            for x in f["metadata/feature_names"][:]
        ]
        info["collection_time_s"] = float(f["metadata"].attrs["collection_time_s"])
        info["receiver_attrs"] = {k: (v.item() if hasattr(v, "item") else v)
                                   for k, v in f["metadata/receiver"].attrs.items()}
        info["dwell_centres_mhz"] = f["metadata/receiver/dwell_centres_mhz"][:].tolist()
        info["dwell_times_s"] = f["metadata/receiver/dwell_times_s"][:].tolist()
        info["receiver_freq_range_mhz"] = f["metadata/receiver/freq_range_mhz"][:].tolist()
        info["num_transmitter_configs"] = len(f["metadata/transmitters"].keys())
    return info


# =====================================================================
# STEP 2 — CLEAN PULSE DATASET
# =====================================================================

def load_pulses(h5_path, scenario_id):
    with h5py.File(h5_path, "r") as f:
        data = f["data"][:]           # [ToA, Freq, PW, AoA, Amp]  -- OBSERVED
        labels = f["labels"][:].flatten()  # emitter_id -- GROUND TRUTH

    df = pd.DataFrame({
        "scenario_id": scenario_id,
        "pulse_id": np.arange(len(data)),
        "time_us": data[:, 0],
        "frequency_mhz": data[:, 1],
        "pulse_width_us": data[:, 2],
        "aoa_deg": data[:, 3],
        "amplitude_db": data[:, 4],
        "emitter_id": labels,
    })
    # TSRD already stores pulses in ascending ToA order; enforce it defensively.
    df = df.sort_values("time_us").reset_index(drop=True)
    df["pulse_id"] = np.arange(len(df))
    return df


# =====================================================================
# STEP 3 — FREQUENCY BANDS  (DERIVED, width justified by OBSERVED receiver config)
# =====================================================================

def build_frequency_bands(width_mhz=BAND_WIDTH_MHZ,
                           fmin=FREQ_RANGE_MIN_MHZ,
                           fmax=FREQ_RANGE_MAX_MHZ):
    starts = np.arange(fmin, fmax, width_mhz)
    bands = pd.DataFrame({
        "band_id": np.arange(len(starts)),
        "band_start_mhz": starts,
        "band_end_mhz": starts + width_mhz,
    })
    return bands


def assign_band(freq_mhz, bands_df, width_mhz=BAND_WIDTH_MHZ, fmin=FREQ_RANGE_MIN_MHZ):
    """DERIVED. Returns band_id in [0, N-1], or -1 if the pulse's frequency
    falls outside the receiver's nominal scan range [fmin, fmax).
    band_id = -1 pulses are PRESERVED in tsrd_pulses.csv but are NOT part
    of the scheduler's action space (the receiver could never have tuned
    there in this scenario's own design)."""
    n_bands = len(bands_df)
    idx = np.floor((freq_mhz - fmin) / width_mhz).astype(int)
    idx = np.where((idx < 0) | (idx >= n_bands), -1, idx)
    return idx


# =====================================================================
# STEP 4 — TIME SLOTS  (DERIVED, ms scale justified by OBSERVED dwell_times_s)
# =====================================================================

def assign_time_slot(time_us, slot_ms=TIME_SLOT_MS):
    return np.floor(time_us / (slot_ms * 1000.0)).astype(int)


# =====================================================================
# STEP 5 — STATIC RF ENVIRONMENT (binary matrix)
# =====================================================================

def build_static_environment(pulses_df, bands_df, n_slots):
    """
    1 = at least one TSRD pulse was OBSERVED in that band during that slot.
    0 = no pulse was observed. This does NOT prove no emitter was
    transmitting -- only that TSRD recorded nothing there.
    Rows = time_slot [0, n_slots), Cols = band_0..band_{N-1}. Pulses with
    band_id == -1 (outside receiver range) are excluded from this matrix.
    """
    n_bands = len(bands_df)
    mat = np.zeros((n_slots, n_bands), dtype=np.int8)
    valid = pulses_df[pulses_df["band_id"] >= 0]
    valid = valid[(valid["time_slot"] >= 0) & (valid["time_slot"] < n_slots)]
    mat[valid["time_slot"].values, valid["band_id"].values] = 1
    env_df = pd.DataFrame(mat, columns=[f"band_{i}" for i in range(n_bands)])
    env_df.insert(0, "time_slot", np.arange(n_slots))
    return env_df, mat


# =====================================================================
# STEP 6 — EMITTER ACTIVITY (evaluation-only view, preserves emitter_id)
# =====================================================================

def build_emitter_activity(pulses_df):
    valid = pulses_df[pulses_df["band_id"] >= 0]
    grouped = valid.groupby(["time_slot", "band_id", "emitter_id"]).agg(
        pulse_count=("pulse_id", "count"),
        first_arrival_time=("time_us", "min"),
        last_arrival_time=("time_us", "max"),
    ).reset_index()
    return grouped.sort_values(["time_slot", "band_id"]).reset_index(drop=True)


# =====================================================================
# STEP 7 — RECEIVER MODEL
# =====================================================================

class Receiver:
    """Wraps the static environment + emitter activity so the scheduler can
    only ever observe the CURRENT time slot's CURRENT selected band. No
    other cell of the matrix is reachable through this interface."""

    def __init__(self, env_matrix, emitter_activity_df, n_slots, n_bands):
        self.env_matrix = env_matrix  # ground-truth-derived binary matrix (internal only)
        self.n_slots = n_slots
        self.n_bands = n_bands
        # Index emitter activity for O(1)-ish lookup per (slot, band)
        self._activity = emitter_activity_df.set_index(["time_slot", "band_id"])

    def observe(self, time_slot, selected_band):
        if selected_band < 0 or selected_band >= self.n_bands:
            raise ValueError(f"selected_band {selected_band} outside valid action space "
                              f"[0, {self.n_bands - 1}]")
        hit = int(self.env_matrix[time_slot, selected_band])
        pulse_count = 0
        emitters = []
        key = (time_slot, selected_band)
        if hit and key in self._activity.index:
            rows = self._activity.loc[[key]]
            pulse_count = int(rows["pulse_count"].sum())
            emitters = sorted(set(rows["emitter_id"].tolist()))
        return {
            "hit": hit,
            "band": selected_band,
            "time_slot": time_slot,
            "pulse_count": pulse_count,
            "emitters": emitters,  # GROUND TRUTH — for evaluation logging only
        }


# =====================================================================
# STEP 8 — SCHEDULERS  (only ever see: time_slot index, n_bands, own history)
# =====================================================================

class BaseScheduler:
    name = "base"

    def __init__(self, n_bands, rng):
        self.n_bands = n_bands
        self.rng = rng

    def select_band(self, state):
        raise NotImplementedError

    def update(self, observation):
        """Optional: called after each observation so online learners
        (e.g. Markov) can update purely from past data."""
        pass


class RoundRobinScheduler(BaseScheduler):
    name = "round_robin"

    def select_band(self, state):
        return state["step_index"] % self.n_bands


class RandomScheduler(BaseScheduler):
    name = "random"

    def select_band(self, state):
        return self.rng.randrange(self.n_bands)


class MarkovScheduler(BaseScheduler):
    """
    State definition: the band that produced the most recent HIT
    (None if no hit has occurred yet in the simulation so far).

    Transition model: counts[state][next_band] = number of times, in the
    OBSERVATION HISTORY SEEN SO FAR (not the full dataset), that a hit in
    `state` was followed (at the hit's own next occurrence) by a hit in
    `next_band`. This is built ONLINE, one time slot at a time, using only
    observations already returned by receiver.observe() in earlier steps
    of this same run -- never future ones.

    Action selection: with probability epsilon, explore (random valid
    band) to keep learning; otherwise exploit the band with the highest
    empirical transition count from the current state. Falls back to
    round-robin cycling when no transition data exists yet for the state.
    """
    name = "markov"

    def __init__(self, n_bands, rng, epsilon=0.15):
        super().__init__(n_bands, rng)
        self.epsilon = epsilon
        self.last_hit_band = None
        self.transition_counts = {}  # {state_band: {next_band: count}}
        self._rr_counter = 0

    def select_band(self, state):
        if self.rng.random() < self.epsilon or self.last_hit_band is None:
            self._rr_counter += 1
            return self.rng.randrange(self.n_bands)
        row = self.transition_counts.get(self.last_hit_band)
        if not row:
            band = self._rr_counter % self.n_bands
            self._rr_counter += 1
            return band
        return max(row, key=row.get)

    def update(self, observation):
        if observation["hit"]:
            if self.last_hit_band is not None:
                row = self.transition_counts.setdefault(self.last_hit_band, {})
                row[observation["band"]] = row.get(observation["band"], 0) + 1
            self.last_hit_band = observation["band"]


# =====================================================================
# STEP 9-10 — RUN SCHEDULERS (no leakage: iterate slots forward in time)
# =====================================================================

def run_scheduler(scheduler, receiver, n_slots):
    rows = []
    for t in range(n_slots):
        state = {"step_index": t, "time_slot": t, "n_bands": receiver.n_bands}
        band = scheduler.select_band(state)
        obs = receiver.observe(t, band)
        scheduler.update(obs)
        rows.append({
            "algorithm": scheduler.name,
            "time_slot": t,
            "selected_band": band,
            "hit": obs["hit"],
            "pulse_count": obs["pulse_count"],
            "detected_emitter_count": len(obs["emitters"]),
            "detected_emitters": ";".join(str(e) for e in obs["emitters"]),
        })
    return pd.DataFrame(rows)


# =====================================================================
# STEP 11 — METRICS
# =====================================================================

def compute_metrics(results_df, n_bands, pulses_df):
    out_rows = []
    # Ground-truth first-arrival time per (band, emitter), restricted to
    # emitters that ever fall inside a valid receiver band.
    valid_pulses = pulses_df[pulses_df["band_id"] >= 0]
    first_seen = valid_pulses.groupby(["band_id", "emitter_id"])["time_us"].min()

    for algo, sub in results_df.groupby("algorithm"):
        num_scans = len(sub)
        num_hits = int(sub["hit"].sum())
        num_misses = num_scans - num_hits
        hit_rate = num_hits / num_scans if num_scans else 0.0
        miss_rate = num_misses / num_scans if num_scans else 0.0
        bands_visited_with_hit = sub.loc[sub["hit"] == 1, "selected_band"].nunique()
        freq_coverage = bands_visited_with_hit / n_bands

        all_emitters = set()
        for e_list in sub.loc[sub["hit"] == 1, "detected_emitters"]:
            if e_list:
                all_emitters.update(int(x) for x in e_list.split(";"))
        unique_emitters_detected = len(all_emitters)

        # ASSUMPTION: intercept time = (time_slot of first scheduler hit for
        # an emitter/band pair) - (time_slot of that emitter's first-ever
        # pulse in that band). Only computable where both exist.
        delays = []
        hits = sub[sub["hit"] == 1]
        seen_pairs = set()
        for _, row in hits.iterrows():
            for e in (row["detected_emitters"].split(";") if row["detected_emitters"] else []):
                e = int(e)
                key = (row["selected_band"], e)
                if key in seen_pairs:
                    continue
                seen_pairs.add(key)
                if key in first_seen.index:
                    true_first_us = first_seen.loc[key]
                    detect_slot_start_us = row["time_slot"] * TIME_SLOT_MS * 1000.0
                    delay_us = max(0.0, detect_slot_start_us - true_first_us)
                    delays.append(delay_us)
        avg_intercept_delay_us = float(np.mean(delays)) if delays else float("nan")

        total_reward = num_hits * REWARD_HIT + num_misses * REWARD_MISS  # ASSUMPTION

        out_rows.append({
            "algorithm": algo,
            "num_scans": num_scans,
            "num_hits": num_hits,
            "num_misses": num_misses,
            "hit_rate": hit_rate,
            "miss_rate": miss_rate,
            "freq_coverage": freq_coverage,
            "unique_emitters_detected": unique_emitters_detected,
            "avg_intercept_delay_us": avg_intercept_delay_us,
            "total_reward_ASSUMPTION": total_reward,
        })
    return pd.DataFrame(out_rows)


# =====================================================================
# MAIN
# =====================================================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--scenario_id", default=None,
                     help="defaults to the input filename stem")
    args = ap.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    scenario_id = args.scenario_id or Path(args.input).stem

    random.seed(RANDOM_SEED)
    rng = random.Random(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    log("Step 1: inspecting file...")
    info = inspect_h5(args.input)
    log(json.dumps({k: v for k, v in info.items() if k != "receiver_attrs"}, indent=2, default=str))

    log("Step 2: loading + cleaning pulses...")
    pulses = load_pulses(args.input, scenario_id)

    log("Step 3: building frequency bands and mapping pulses...")
    bands = build_frequency_bands()
    pulses["band_id"] = assign_band(pulses["frequency_mhz"].values, bands)

    log("Step 4: building time slots...")
    pulses["time_slot"] = assign_time_slot(pulses["time_us"].values)
    n_slots = int(pulses["time_slot"].max()) + 1
    log(f"  -> {n_slots} time slots of {TIME_SLOT_MS} ms "
        f"(covers {n_slots * TIME_SLOT_MS / 1000:.2f}s of the "
        f"{info['collection_time_s']}s scenario)")

    log("Step 5: building static RF environment matrix...")
    env_df, env_matrix = build_static_environment(pulses, bands, n_slots)

    log("Step 6: building emitter activity table...")
    emitter_activity = build_emitter_activity(pulses)

    log("Step 7-9: running schedulers (Round Robin, Random, Markov)...")
    n_bands = len(bands)
    receiver = Receiver(env_matrix, emitter_activity, n_slots, n_bands)

    schedulers = [
        RoundRobinScheduler(n_bands, random.Random(RANDOM_SEED)),
        RandomScheduler(n_bands, random.Random(RANDOM_SEED + 1)),
        MarkovScheduler(n_bands, random.Random(RANDOM_SEED + 2)),
    ]
    all_results = []
    for sched in schedulers:
        res = run_scheduler(sched, receiver, n_slots)
        all_results.append(res)
        log(f"  -> {sched.name}: {res['hit'].sum()} hits / {len(res)} scans "
            f"({100 * res['hit'].mean():.2f}% hit rate)")
    results_df = pd.concat(all_results, ignore_index=True)

    log("Step 11: computing metrics...")
    metrics_df = compute_metrics(results_df, n_bands, pulses)

    log("Step 12: writing output files...")
    pulses.to_csv(out_dir / "tsrd_pulses.csv", index=False)
    bands.to_csv(out_dir / "frequency_bands.csv", index=False)
    env_df.to_csv(out_dir / "static_environment.csv", index=False)
    emitter_activity.to_csv(out_dir / "emitter_activity.csv", index=False)
    results_df.to_csv(out_dir / "scheduler_results.csv", index=False)
    metrics_df.to_csv(out_dir / "metrics.csv", index=False)

    log("Done.")
    return {
        "info": info,
        "pulses": pulses,
        "bands": bands,
        "env_df": env_df,
        "env_matrix": env_matrix,
        "emitter_activity": emitter_activity,
        "results_df": results_df,
        "metrics_df": metrics_df,
        "n_slots": n_slots,
        "n_bands": n_bands,
    }


if __name__ == "__main__":
    main()
