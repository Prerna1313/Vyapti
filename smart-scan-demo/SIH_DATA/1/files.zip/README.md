# TSRD → PS26055 Static Scheduler Environment

Converts one TSRD scan-mode scenario (`config_0.h5`) into a static,
scheduler-friendly RF environment, and runs three baseline scan-scheduling
algorithms against it: Round Robin, Random, and a Markov (online-learned)
scheduler.

**Source file:** `config_0.h5` (Turing Synthetic Radar Dataset, scan-mode).
TSRD was built for radar pulse deinterleaving, not PS26055 — everything
below is labeled by how it relates to that fact.

Run: `python convert_tsrd.py --input config_0.h5 --output data/`

---

## 1. What's actually in the file (OBSERVED)

| | |
|---|---|
| Pulses | 169,617 |
| Features per pulse | `[ToA (µs), Frequency (MHz), PulseWidth (µs), AoA (deg), Amplitude (dBm)]` |
| Emitter labels | `int8`, 96 transmitter configs *defined* in metadata, but only **72** ever produce a pulse in this scenario (24 are silent — out of range/power/geometry for this run) |
| Scenario duration | `collection_time_s = 30.0` metadata attr; pulses actually span 0.20 – 29.20 s |
| Frequency range | 10.36 – 10,999.57 MHz observed (pulses exist well below the receiver's nominal floor) |
| Pulse width | 0.0069 – 346.27 µs |
| AoA | -179.99° to 179.99° |
| Amplitude | -170.48 to -1.25 dBm |
| Receiver config used to *collect* this scenario | `bandwith_mhz=500`, 36 `dwell_centres_mhz` spaced exactly 500 MHz apart (250…17750 MHz), `dwell_times_s` alternating 0.05/0.1 s, `scan_mode="Scanning"` |

**Metadata inconsistency found and resolved:** `metadata/receiver/freq_range_mhz`
states `[500, 18000]`, but `dwell_centres_mhz` (the more granular field)
implies the real scanned range is **0–18000 MHz** (36 × 500 MHz, first
centre at 250 MHz covers 0–500 MHz). Trusting the coarser `freq_range_mhz`
field would have silently dropped 9,299 real pulses (5.5% of the dataset)
that fall in 0–500 MHz. We used `dwell_centres_mhz` as ground truth instead,
so **zero pulses were discarded** as out-of-range.

## 2. Frequency-band design (DERIVED, width justified by OBSERVED data)

`BAND_WIDTH_MHZ = 500`, range `0–18000 MHz` → **36 bands**, `band_id 0..35`.

This is not an arbitrary choice: it exactly reproduces the instantaneous
bandwidth and band layout TSRD's own receiver used to generate this
scenario (`bandwith_mhz` + `dwell_centres_mhz`). Of the 36 bands, **16 are
ever occupied** by a pulse in this scenario; the rest are structurally
empty for this particular emitter mix. See `plots/01_frequency_distribution.png`.

## 3. Time-slot design (ASSUMPTION, scale justified by OBSERVED data)

`TIME_SLOT_MS = 50` → **584 time slots** covering the 29.2s of observed
pulse activity.

TSRD's own receiver dwell times alternate between 50ms and 100ms per band.
We used the finer end (50ms) as a uniform slot size for this static
baseline — a genuine simulation design choice, not something extracted
from the file. A coarser or finer value is a one-line config change
(`TIME_SLOT_MS` at the top of `convert_tsrd.py`) and everything downstream
regenerates from it.

## 4. Meaning of 0/1 in `static_environment.csv`

`1` = at least one TSRD pulse was **observed/recorded** in that band during
that time slot.
`0` = no pulse was recorded.

**`0` does NOT mean "no emitter was transmitting."** It only means TSRD's
synthetic pulse generator produced nothing there — there is no independent
ground truth in this file about continuous transmitter state between
pulses, so we cannot and do not claim stronger than "not observed."

## 5. Receiver model / HIT-MISS definition

- `Receiver.observe(time_slot, selected_band)` looks up **exactly one**
  cell of the (time_slot × band) matrix — the one the scheduler picked —
  and nothing else.
- `HIT` = 1 if a pulse was recorded in that cell; `MISS` = 0 otherwise.
- The returned `emitters` list (ground truth) is included in the
  observation **for evaluation logging only**; no scheduler in this repo
  reads or uses it when choosing its next band.

## 6. Schedulers implemented (Step 8)

- **RoundRobinScheduler** — cycles `band = step_index % 36`.
- **RandomScheduler** — uniform random band each slot.
- **MarkovScheduler** — state = *the band of the most recent HIT* (or
  `None` before the first hit). Maintains an online transition-count table
  built only from observations already returned earlier in the same run
  (never future ones); picks the band with the highest empirical
  transition probability from the current state, with ε=0.15 random
  exploration and round-robin fallback when a state is still unseen.

## 7. Data-leakage boundary (Step 9)

| | Given to scheduler? |
|---|---|
| Current time slot index | Yes |
| Number of valid bands | Yes |
| Own past selections/observations | Yes (schedulers may keep their own history) |
| Full `static_environment.csv` matrix | **No** — schedulers never see it; only `Receiver.observe()` outputs |
| `emitter_id` at decision time | **No** — only surfaced afterward, in results/metrics, for evaluation |
| Future pulses / future observations | **No** — simulation loop iterates slots strictly forward |

Ground truth / Observation / Action / Result are kept in separate columns
throughout (`emitter_activity.csv` = ground truth+observation view,
`scheduler_results.csv` = action+result view).

## 8. Metrics (Step 11), all in `metrics.csv`

| Column | Meaning | Type |
|---|---|---|
| `num_scans`, `num_hits`, `num_misses` | raw counts | DERIVED |
| `hit_rate`, `miss_rate` | hits/scans, misses/scans | DERIVED |
| `freq_coverage` | distinct bands with ≥1 hit ÷ 36 | DERIVED |
| `unique_emitters_detected` | distinct ground-truth `emitter_id`s ever present in a hit cell | DERIVED (uses ground truth for *evaluation*, not decision-making) |
| `avg_intercept_delay_us` | mean(time the scheduler first hit a (band, emitter) − that emitter's true first pulse time in that band) | DERIVED, only over pairs where both exist |
| `total_reward_ASSUMPTION` | `hits × 1 + misses × 0` | **ASSUMPTION** — not derived from TSRD; a placeholder reward function so the pipeline has *some* scalar objective. Change freely. |

## 9. Results on `config_0.h5` (this run)

| algorithm | scans | hits | hit_rate | freq_coverage | unique_emitters_detected |
|---|---|---|---|---|---|
| round_robin | 584 | 15 | 2.57% | 25.0% | 38 |
| random | 584 | 15 | 2.57% | 22.2% | 20 |
| markov | 584 | 42 | 7.19% | 22.2% | 36 |

These are sanity-check baselines on **one scenario, one random seed** —
not a claim that Markov "beats" round robin in general. Re-run with
different seeds / scenarios before drawing conclusions.

## 10. Output files

```
data/
├── tsrd_pulses.csv        # every pulse, OBSERVED fields + DERIVED band_id/time_slot + GROUND TRUTH emitter_id
├── frequency_bands.csv    # band_id, band_start_mhz, band_end_mhz (DERIVED)
├── static_environment.csv # time_slot x band binary matrix (DERIVED)
├── emitter_activity.csv   # time_slot, band_id, emitter_id, pulse_count, first/last arrival (GROUND TRUTH, eval-only)
├── scheduler_results.csv  # per-algorithm, per-slot action + result
└── metrics.csv            # per-algorithm summary metrics
plots/
├── 01_frequency_distribution.png
├── 02_arrival_time_distribution.png
├── 03_time_frequency_heatmap.png   # shows frequency-agile emitters as diagonal streaks — validates the conversion
├── 04_active_bands_over_time.png
└── 05_emitter_activity.png
```

## 11. What can we honestly validate?

**A. Directly supported by TSRD (observed):** pulse-level ToA, frequency,
pulse width, AoA, amplitude; which emitter emitted each pulse; the
receiver bandwidth/dwell config used to generate the scenario.

**B. Derived from TSRD (deterministic transforms):** band assignment,
time-slot assignment, the binary occupancy matrix, hit/miss outcomes for
each scheduler's chosen actions, coverage/hit-rate metrics.

**C. Simulation assumptions (our choices, not TSRD facts):** 50ms slot
size, the ±ε exploration and state definition inside `MarkovScheduler`,
the `total_reward_ASSUMPTION` reward function.

**D. Cannot be validated without real-world RF data:** whether these
hit-rate numbers say anything about real electronic-warfare receiver
performance, whether "no pulse observed" cells really had no transmitter
active, and whether the relative ranking of algorithms here would hold
under a live, non-synthetic RF environment. TSRD is a *pulse* dataset built
for deinterleaving research; it was never validated as a scan-scheduling
benchmark, and this pipeline does not change that — it only gives you a
common, leakage-safe input format so different scheduling algorithms can
be compared fairly *against each other*, on *this* synthetic scenario.

## 12. Known limitations

- Single scenario (`config_0.h5`); no cross-scenario generalization claims.
- Static environment only — no closed-loop emitter reaction to being
  scanned (TSRD pulses don't change based on scheduler behavior).
- `avg_intercept_delay_us` uses time-slot-start as the detection timestamp,
  which introduces up to one slot (50ms) of quantization error.
- The Markov scheduler's ε and state definition are simple by design (this
  is Step 8's baseline, not the final Step 15 ML/RL approach you mentioned
  is planned later).
